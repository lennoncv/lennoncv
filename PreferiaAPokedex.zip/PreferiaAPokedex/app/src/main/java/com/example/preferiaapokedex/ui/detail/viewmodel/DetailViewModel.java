package com.example.preferiaapokedex.ui.detail.viewmodel;

import com.example.preferiaapokedex.model.Movie;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.preferiaapokedex.MoviesRepository;


public final class DetailViewModel extends ViewModel {
    private MoviesRepository mMoviesRepository;

    DetailViewModel(MoviesRepository moviesRepository) {
        mMoviesRepository = moviesRepository;
    }

    public Movie getMovieDetails(int movieId) {
        return mMoviesRepository
                .getMovieDetails(movieId);
    }

    public void favouriteMovie(Movie movie) {
        mMoviesRepository.favouriteMovieOps(movie);
    }

    public LiveData<Movie> getFav(int movieId) {
        return mMoviesRepository.getSpecificFavouriteMovie(movieId);
    }
}


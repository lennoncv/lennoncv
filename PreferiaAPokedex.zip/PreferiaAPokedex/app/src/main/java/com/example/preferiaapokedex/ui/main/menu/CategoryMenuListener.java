package com.example.preferiaapokedex.ui.main.menu;

import android.view.MenuItem;
import android.widget.PopupMenu;

import com.example.preferiaapokedex.R;
import com.example.preferiaapokedex.model.Category;
import com.example.preferiaapokedex.ui.main.async.MovieListAsync;
import com.example.preferiaapokedex.ui.main.callbacks.FavouriteMoviesCallback;
import com.example.preferiaapokedex.ui.main.callbacks.MovieListCallBack;
import com.example.preferiaapokedex.ui.main.viewmodel.MainViewModel;


public class CategoryMenuListener implements PopupMenu.OnMenuItemClickListener {

    private MovieListCallBack mMovieListCallBackContext;
    private FavouriteMoviesCallback mFavouriteMoviesCallbackContext;
    private MainViewModel mMainViewModel;

    public CategoryMenuListener(MainViewModel mainViewModel, MovieListCallBack movieListCallBackContext, FavouriteMoviesCallback favouriteMoviesCallbackContext) {
        this.mMovieListCallBackContext = movieListCallBackContext;
        this.mMainViewModel = mainViewModel;
        this.mFavouriteMoviesCallbackContext = favouriteMoviesCallbackContext;
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_sort_top_rated:
                new MovieListAsync(mMainViewModel, Category.TOP_RATED, mMovieListCallBackContext).execute();
                return true;
            case R.id.action_sort_upcoming:
                new MovieListAsync(mMainViewModel, Category.UPCOMING, mMovieListCallBackContext).execute();
                return true;
            case R.id.action_sort_most_popular:
                new MovieListAsync(mMainViewModel, Category.POPULAR, mMovieListCallBackContext).execute();
                return true;
            case R.id.action_sort_favourites:
                mFavouriteMoviesCallbackContext.loadFavouriteMovies();
                return true;
        }
        return false;
    }
}

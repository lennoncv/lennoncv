package com.example.preferiaapokedex.ui.detail.async;

import android.os.AsyncTask;

import com.example.preferiaapokedex.model.Movie;
import com.example.preferiaapokedex.ui.detail.viewmodel.DetailViewModel;


public final class MovieDetailsAsyncTask extends AsyncTask<Integer, Void, Movie> {

    private DetailViewModel mDetailViewModel;
    private MovieDetailsCallBack mMovieDetailsCallBack;

    public MovieDetailsAsyncTask(DetailViewModel detailViewModel, MovieDetailsCallBack movieDetailsCallBack) {
        mDetailViewModel = detailViewModel;
        mMovieDetailsCallBack = movieDetailsCallBack;
    }

    @Override
    protected Movie doInBackground(Integer... integers) {
        Movie vMovie = mDetailViewModel.getMovieDetails(integers[0]);
        return vMovie;
    }

    @Override
    protected void onPostExecute(Movie movie) {
        super.onPostExecute(movie);
        //mMovieDetailsCallBack.complete(movie);
    }
}
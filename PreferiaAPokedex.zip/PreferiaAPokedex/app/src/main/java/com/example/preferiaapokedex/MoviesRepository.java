package com.example.preferiaapokedex;

import androidx.lifecycle.LiveData;
import android.util.Log;
import java.io.IOException;
import java.util.List;
import com.example.preferiaapokedex.db.dao.FavouriteMovieDao;
import com.example.preferiaapokedex.model.Category;
import com.example.preferiaapokedex.model.Movie;
import com.example.preferiaapokedex.model.responses.MovieListResponse;
import com.example.preferiaapokedex.network.MovieApiServices;
import com.example.preferiaapokedex.util.threads.AppExecutors;

public final class MoviesRepository {

        //    TODO 1.(MoviesRepository) - Use MutableLiveData with Network Calls and set Value
        private static MoviesRepository sMoviesRepository;
        private MovieApiServices mMovieApiServices;
        private FavouriteMovieDao mMovieDao;
        private AppExecutors mThreadAppExecutors;
        private static final Object LOCK = new Object();
        private MovieListResponse mMovieListResponse;
        private Movie mMovie;
        private final String TAG = MoviesRepository.class.getSimpleName();
        private String language;


        private MoviesRepository(MovieApiServices movieApiServices, FavouriteMovieDao movieDao, AppExecutors threadAppExecutors, String language) {
            mMovieApiServices = movieApiServices;
            mMovieDao = movieDao;
            mThreadAppExecutors = threadAppExecutors;
            this.language = language;
        }

        public synchronized static MoviesRepository getInstance(FavouriteMovieDao movieDao, MovieApiServices movieApiServices, AppExecutors threadAppExecutors, String language) {
            if (sMoviesRepository == null) {
                synchronized (LOCK) {
                    sMoviesRepository = new MoviesRepository(movieApiServices, movieDao, threadAppExecutors, language);
                }
            }
            return sMoviesRepository;
        }

        public LiveData<List<Movie>> getFavouriteMovies() {
            return mMovieDao.loadAll();
        }

        public LiveData<Movie> getSpecificFavouriteMovie(int id) {
            return mMovieDao.loadById(id);
        }

        public void favouriteMovieOps(final Movie movie) {
            mThreadAppExecutors.diskIO().execute(new Runnable() {
                @Override
                public void run() {
                    if (mMovieDao.checkForFavs(movie.getMovieId(), movie.getMovieTitle()) != null) {
                        mMovieDao.removeFromFavourites(movie);
                        Log.d(TAG, "Movie Deleted");
                    } else {
                        mMovieDao.addToFavourites(movie);
                        Log.d(TAG, "Movie Saved");
                    }
                }
            });
        }

        public MovieListResponse getMovies(Category category, final int page) {
            switch (category) {
                case POPULAR:
                    loadPopularMovies(page);
                    break;
                case UPCOMING:
                    loadUpcomingMovies(page);
                    break;
                case TOP_RATED:
                    loadTopRatedMovies(page);
                    break;
            }
            return mMovieListResponse != null ? mMovieListResponse : new MovieListResponse();
        }

        private void loadTopRatedMovies(int page) {
            try {
                mMovieListResponse = mMovieApiServices
                        .getTopRatedMovies(BuildConfig.API_KEY, language, page)
                        .execute()
                        .body();
                Log.d(TAG, "Upcoming Movies Loaded");
            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
            }
        }

        private void loadUpcomingMovies(int page) {
            try {
                mMovieListResponse = mMovieApiServices
                        .getUpcomingMovies(BuildConfig.API_KEY, language, page)
                        .execute()
                        .body();
                Log.d(TAG, "Top Rated Movies Loaded");
            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
            }
        }

        private void loadPopularMovies(int page) {
            try {
                mMovieListResponse = mMovieApiServices
                        .getPopularMovies(BuildConfig.API_KEY, language, page)
                        .execute()
                        .body();
                Log.d(TAG, "Popular Movies Loaded");
            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
            }
        }

        public Movie getMovieDetails(final int movieId) {
            try {
                mMovie = mMovieApiServices
                        .getMovie(movieId, BuildConfig.API_KEY, language)
                        .execute()
                        .body();
            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
            }
            return mMovie != null ? mMovie : getDefaultMovie();
        }

        private Movie getDefaultMovie() {
            mMovie = new Movie();
            return mMovie;
        }


    }

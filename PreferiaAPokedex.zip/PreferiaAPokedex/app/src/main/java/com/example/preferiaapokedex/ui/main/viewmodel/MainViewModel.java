package com.example.preferiaapokedex.ui.main.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import com.example.preferiaapokedex.MoviesRepository;
import com.example.preferiaapokedex.model.Category;
import com.example.preferiaapokedex.model.Movie;
import com.example.preferiaapokedex.model.MovieNetworkLite;
import com.example.preferiaapokedex.model.responses.MovieListResponse;


public final class MainViewModel extends ViewModel {
    private MoviesRepository mMoviesRepository;

    MainViewModel(MoviesRepository moviesRepository) {
        mMoviesRepository = moviesRepository;
    }

    public List<MovieNetworkLite> getMovies(Category category, int page) {
        MovieListResponse vMovieListResponse = mMoviesRepository
                .getMovies(category, page);
        return page <= vMovieListResponse.getTotalPages() ? vMovieListResponse.getMoviesResult() : null;
    }

    public LiveData<List<Movie>> getFavouriteMovies() {
        return mMoviesRepository.getFavouriteMovies();
    }
}

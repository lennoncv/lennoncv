package com.example.preferiaapokedex.ui.main.callbacks;

public interface FavouriteMoviesCallback {

    void loadFavouriteMovies();
}

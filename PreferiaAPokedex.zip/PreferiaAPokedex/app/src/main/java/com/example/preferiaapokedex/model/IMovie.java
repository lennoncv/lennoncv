package com.example.preferiaapokedex.model;

public interface IMovie {

    String getMoviePoster();

    float getVoterAverage();

    int getMovieId();
}
package com.example.preferiaapokedex.ui.main.callbacks;

import java.util.List;

import com.example.preferiaapokedex.model.Category;
import com.example.preferiaapokedex.model.MovieNetworkLite;


public interface MovieListCallBack {

    void inProgress();
    void onFinished(List<MovieNetworkLite> movies, Category category);
}

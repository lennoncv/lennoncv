package com.example.preferiaapokedex.ui.detail;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.Nullable;

import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toolbar;

import com.example.preferiaapokedex.ui.detail.viewmodel.DetailViewModel;
import com.example.preferiaapokedex.ui.detail.viewmodel.DetailViewModelFactory;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import org.parceler.Parcels;

import butterknife.BindView;
import butterknife.ButterKnife;
import com.example.preferiaapokedex.R;
import com.example.preferiaapokedex.model.Movie;
import com.example.preferiaapokedex.ui.detail.async.MovieDetailsAsyncTask;
import com.example.preferiaapokedex.ui.detail.async.MovieDetailsCallBack;
import com.example.preferiaapokedex.util.InjectorUtils;
import com.example.preferiaapokedex.util.BackdropImgView;
import com.example.preferiaapokedex.util.PosterImgView;
import com.example.preferiaapokedex.util.threads.AppExecutors;

import static com.example.preferiaapokedex.util.Constants.BACKDROP_BASE_URL;
import static com.example.preferiaapokedex.util.Constants.KEY_MOVIE_ID;
import static com.example.preferiaapokedex.util.Constants.KEY_MOVIE_IS_FAVOURITE;
import static com.example.preferiaapokedex.util.Constants.KEY_MOVIE_POSTER;
import static com.example.preferiaapokedex.util.Constants.POSTER_BASE_URL;
import static com.example.preferiaapokedex.util.PaletteExtractorUtil.getBitmapFromUrl;
import static com.example.preferiaapokedex.util.PaletteExtractorUtil.getDarkVibrantColor;

public abstract class MovieDetailActivity extends AppCompatActivity implements MovieDetailsCallBack, SharedPreferences.OnSharedPreferenceChangeListener {
    private final String KEY_MOVIE_PERSISTENCE = "movie";
    @BindView(R.id.toolbar_details)
    Toolbar mToolbar;
    //@BindView(R.id.poster_img_details)
    //PosterImgView vPosterImgView;
    //@BindView(R.id.backdrop_img_view)
  //BackdropImgView mBackdropImgView;
    @BindView(R.id.collapsingToolbar)
    CollapsingToolbarLayout vCollapsingToolbarLayout;
    @BindView(R.id.text_view_movie_title)
    TextView tvMovieTitle;
    @BindView(R.id.rating_bar_movie_avg)
    RatingBar rbMovieRating;
    @BindView(R.id.text_view_release_date)
    //TextView tvReleaseDate;
    //@BindView(R.id.text_view_overview)
    //ImageView ivFavourites;

    private int mMovieId;
    private String mMoviePoster;
    private Movie mMovie;
    private DetailViewModel detailViewModel;
    private boolean mIsFavourite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        ButterKnife.bind(this);
        supportPostponeEnterTransition();
        //setupToolBar();
      //  vPosterImgView.setTransitionName("poster");
        Intent intent = getIntent();
        if (intent.getExtras() != null) {
            mMovieId = intent.getExtras().getInt(KEY_MOVIE_ID, -1);
            mMoviePoster = intent.getStringExtra(KEY_MOVIE_POSTER);
            mIsFavourite = intent.getBooleanExtra(KEY_MOVIE_IS_FAVOURITE, false);
        }
        //posterImageTransition();
        DetailViewModelFactory vDetailViewModelFactory = InjectorUtils.provideDetailViewModelFactory(this, this);
        detailViewModel = ViewModelProviders.of(this, vDetailViewModelFactory).get(DetailViewModel.class);
        //checkIfFavourite(mMovieId);
        if (savedInstanceState != null) {
            mMovie = Parcels.unwrap(savedInstanceState.getParcelable(KEY_MOVIE_PERSISTENCE));
            complete(mMovie);
        } else {
            if (!mIsFavourite) {
                new MovieDetailsAsyncTask(detailViewModel, this).execute(mMovieId);
            } else {
                loadMovieDetailsFromCache();
            }
        }
    }

    private void loadMovieDetailsFromCache() {
        detailViewModel.getFav(mMovieId).observe(this, new Observer<Movie>() {
            @Override
            public void onChanged(@Nullable Movie movie) {
                if (movie != null) {
                    mMovie = movie;
                    complete(mMovie);
                }
            }
        });
    }

 /*   private void setupToolBar() {
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private void checkIfFavourite(int movieId) {
        detailViewModel.getFav(movieId).observe(this, new Observer<Movie>() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onChanged(@Nullable Movie movie) {
                if (movie != null) {
                    ivFavourites.setImageDrawable(getDrawable(R.drawable.ic_favorite_true));
                } else {
                    ivFavourites.setImageDrawable(getDrawable(R.drawable.ic_favorite_false));
                }
            }
        });
    }
*/
/*    private void posterImageTransition() {
        Picasso.with(this)
                .load(POSTER_BASE_URL + mMoviePoster)
                .into(vPosterImgView, new Callback() {
                    @Override
                    public void onSuccess() {
                        supportStartPostponedEnterTransition();
                    }

                    @Override
                    public void onError() {
                        supportStartPostponedEnterTransition();
                    }
                });
    }
*/
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mMovie != null)
            outState.putParcelable(KEY_MOVIE_PERSISTENCE, Parcels.wrap(mMovie));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            supportFinishAfterTransition();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void setStatusBarColorFromBackdrop(final String url) {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        AppExecutors.getInstance().networkIO().execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap sBitmap = getBitmapFromUrl(url);
                runOnUiThread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                    @Override
                    public void run() {
                        int backGroundColor = ContextCompat.getColor(getBaseContext(), R.color.colorPrimaryDark);
                        if (getDarkVibrantColor(sBitmap) != null) {
                            backGroundColor = getDarkVibrantColor(sBitmap).getRgb();
                        }
                        getWindow().setStatusBarColor(backGroundColor);
                        vCollapsingToolbarLayout.setContentScrimColor(backGroundColor);
                    }
                });
            }
        });
    }

  /*  @Override
    public void complete(final Movie movie) {
        setStatusBarColorFromBackdrop(BACKDROP_BASE_URL + movie.getBackdrop());
        Picasso.with(MovieDetailActivity.this)
                .load(BACKDROP_BASE_URL + movie.getBackdrop())
                .into(mBackdropImgView);
        vCollapsingToolbarLayout.setTitleEnabled(false);
        tvMovieTitle.setText(movie.getMovieTitle());
        //rbMovieRating.setRating(movie.getVoterAverage() / 2);
        tvReleaseDate.setText(movie.getMovieReleaseDate());
     //   tvOverview.setText(movie.getMovieOverview());
        mMovie = movie;
        ivFavourites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detailViewModel.favouriteMovie(movie);
            }
        });
    }
*/
    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

    }
}

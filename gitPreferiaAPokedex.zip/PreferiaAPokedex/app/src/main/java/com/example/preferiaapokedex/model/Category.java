package com.example.preferiaapokedex.model;

public enum Category {

    POPULAR, UPCOMING, TOP_RATED

}
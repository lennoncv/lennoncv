package com.example.preferiaapokedex;

import android.app.Application;

import com.squareup.leakcanary.LeakCanary;

public final class PreferiaApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        PreferiaApplication vInstance = this;
        if (LeakCanary.isInAnalyzerProcess(vInstance)) {
            return;
        }
        LeakCanary.install(vInstance);
    }
}

package com.example.preferiaapokedex.ui.detail.async;

import com.example.preferiaapokedex.model.Movie;


public interface MovieDetailsCallBack {

    void complete(Movie movie);
}

package com.example.preferiaapokedex.ui.main;

import android.content.Context;
import android.content.res.Configuration;
import java.util.Locale;
import com.example.preferiaapokedex.R;


final class Language {
    static void setUpLocale(String language, Context context) {
        if (language.equals(context.getString(R.string.pref_language_val_portuguese))) {
            Locale locale = new Locale("pt-BR");
            configLocale(context, locale);
        }
    }

    private static void configLocale(Context context, Locale locale) {
        Locale.setDefault(locale);
        Configuration config = context.getResources().getConfiguration();
        config.setLocale(locale);
        context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
    }
}
